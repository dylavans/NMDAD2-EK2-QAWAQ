/**
 * @author    Olivier Parent
 * @copyright Copyright © 2015-2016 Artevelde University College Ghent
 * @license   Apache License, Version 2.0
 */
;(function () {
    'use strict';

    angular.module('app.store')
        .controller('StoreController', StoreController);

    /* @ngInject */
    function StoreController(
        // Angular
        $log,
        // Third-party Modules
        $state,
        // Third-party Libraries

        // Custom
        // $http
    ) {
        $log.info(StoreController.name, Date.now());
        $log.log('Current state name:', $state.current.name);

        // ViewModel
        // =========
        var vm = this;

        // Interaction
        // -----------
        // User Interface
        // --------------
        vm.$$ui = {
            menu: [
                { label: 'Blog'       , uri: '#/blog'       , state: 'blog.posts' , },
                { label: 'Store'       , uri: '#/store'       , state: 'store' , },
                { label: 'Style Guide', uri: '#/style-guide', state: 'style-guide' },
                { label: 'Contact', uri: '#/contact', state: 'contact' }

            ],
            title: 'Store'
        }



    }

})();
