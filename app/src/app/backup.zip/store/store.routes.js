/**
 * @author    Olivier Parent
 * @copyright Copyright © 2015-2016 Artevelde University College Ghent
 * @license   Apache License, Version 2.0
 */
;(function () {
    'use strict';

    angular.module('app.store')
        .config(Routes);

    /* @ngInject */
    function Routes(
        // Angular
        $stateProvider
    ) {
        $stateProvider
            .state('store', {
                cache: false, // false will reload on every visit.
                controller: 'StoreController as vm',
                templateUrl: 'html/store/store.view.html'
            })
            /*
            .state('store.products', {
                cache: false, // false will reload on every visit.
                templateUrl: 'html/store/store-products.partial.html',
                url: '/store'
            })
            .state('store.product', {
                cache: false, // false will reload on every visit.
                controller: 'ProductController as vm',
                templateUrl: 'html/store/store-product.partial.html',
            })
            .state('store.product.create', {
                cache: false, // false will reload on every visit.
                templateUrl: 'html/store/product-form.partial.html',
                url: '/store/products/create'
            })
            .state('store.product.edit', {
                cache: false, // false will reload on every visit.
                templateUrl: 'html/store/product-form.partial.html',
                url: '/store/products/{product_id:int}/edit'
            })
            .state('store.product.show', {
                cache: false, // false will reload on every visit.
                templateUrl: 'html/store/product.partial.html',
                url: '/store/products/{product_id:int}'
            });
            */
    }

})();
